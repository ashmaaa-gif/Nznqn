
const questions = [
    {
        question: "What is the normal range for adult respiratory rate?",
        options: ["8-12 breaths per minute", "12-20 breaths per minute", "20-28 breaths per minute", "28-36 breaths per minute"],
        answer: 1,
        rationale: "The normal adult respiratory rate is 12-20 breaths per minute."
    },
    {
        question: "Which organ is primarily responsible for insulin production?",
        options: ["Liver", "Pancreas", "Kidney", "Spleen"],
        answer: 1,
        rationale: "Insulin is produced by the beta cells in the pancreas."
    }
];
